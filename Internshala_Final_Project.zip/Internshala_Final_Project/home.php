<?php
session_start();
if(!isset($_SESSION['name'])){
   
   header('Location:index.php');
    exit();
}
 

?>
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>home</title>
        <?php
          include ("includes/links.php");
         ?>
    </head>
    <body>
        <?php
          include ("includes/homeheader.php");
         ?>
        <div class="container-fluid">
            <div class="row">
                <div class="col-xs-3 margin">
                    <div class="panel panel-default">
                        <div class="panel-heading panel-b0">
                            <h4>#1</h4>
                        </div>
                        <div class="panel-body panelimg">
                            <div class="inner">
                                <img src="img/10.jpg" class="img-responsive" alt="responsive image">
                            </div>
                             <p>
                                 2 MP camera<br>
                                 Rs.2000
                             </p>
                             <button class="btn btn-success btn-block">ADD TO CART</button>
                        </div>
                          
                    </div>
                </div>
                <div class="col-xs-3 margin">
                    <div class="panel panel-default">
                        <div class="panel-heading panel-b0">
                           <h4>#2</h4>
                        </div>
                        <div class="panel-body panelimg">
                            <div class="inner">
                                <img src="img/9.jpg" class="img-responsive" alt="responsive image">
                            </div>
                             <p>
                                 2 MP camera<br>
                                 Rs.2000
                             </p>
                             <button class="btn btn-success btn-block">ADD TO CART</button>
                        </div>
                          
                    </div>
                </div>
                <div class="col-xs-3 margin">
                    <div class="panel panel-default">
                        <div class="panel-heading panel-b0">
                            <h4>#3</h4>
                        </div>
                        <div class="panel-body panelimg">
                            <div class="inner">
                                 <img src="img/8.jpg" class="img-responsive" alt="responsive image">
                            </div>
                             <p>
                                 2 MP camera<br>
                                 Rs.2000
                             </p>
                             <button class="btn btn-success btn-block">ADD TO CART</button>
                        </div>
                          
                    </div>
                </div>
           
             <div class="col-xs-3 margin">
                    <div class="panel panel-default">
                        <div class="panel-heading panel-b0">
                           <h4>#4</h4>
                        </div>
                        <div class="panel-body panelimg">
                            <div class="inner">
                                <img src="img/7.jpg" class="img-responsive" alt="responsive image">
                            </div>
                             <p>
                                 2 MP camera<br>
                                 Rs.2000
                             </p>
                             <button class="btn btn-success btn-block">ADD TO CART</button>
                        </div>
                          
                    </div>
                </div>
             </div>    
            <div class="row margin-btm">
                <div class="col-xs-2">
                    <div class="panel panel-default">
                        <div class="panel-heading panel-b0">
                            <h4>#5</h4>
                        </div>
                        <div class="panel-body panelimg">
                            <div class="inner">
                                 <img src="img/6.jpg" class="img-responsive" alt="responsive image">
                            </div>
                             <p>
                                 2 MP camera<br>
                                 Rs.2000
                             </p>
                             <button class="btn btn-success btn-block">ADD TO CART</button>
                        </div>
                          
                    </div>
                </div>
                <div class="col-xs-2">
                    <div class="panel panel-default">
                        <div class="panel-heading panel-b0">
                            <h4>#6</h4>
                        </div>
                        <div class="panel-body panelimg">
                            <div class="inner">
                                 <img src="img/5.jpg" class="img-responsive" alt="responsive image">
                            </div>
                             <p>
                                 2 MP camera<br>
                                 Rs.2000
                             </p>
                             <button class="btn btn-success btn-block">ADD TO CART</button>
                        </div>
                          
                    </div>
                </div>
                <div class="col-xs-2">
                    <div class="panel panel-default">
                        <div class="panel-heading panel-b0">
                            <h4>#7</h4>
                        </div>
                        <div class="panel-body panelimg">
                            <div class="inner">
                                <img src="img/4.jpg" class="img-responsive" alt="responsive image">
                            </div>
                             <p>
                                 2 MP camera<br>
                                 Rs.2000
                             </p>
                             <button class="btn btn-success btn-block">ADD TO CART</button>
                        </div>
                          
                    </div>
                </div>
                 <div class="col-xs-2">
                    <div class="panel panel-default">
                        <div class="panel-heading panel-b0">
                            <h4>#8</h4>
                        </div>
                        <div class="panel-body panelimg">
                            <div class="inner">
                                 <img src="img/3.jpg" class="img-responsive" alt="responsive image">
                            </div>
                             <p>
                                 2 MP camera<br>
                                 Rs.2000
                             </p>
                             <button class="btn btn-success btn-block">ADD TO CART</button>
                        </div>
                          
                    </div>
                </div>
                <div class="col-xs-2">
                    <div class="panel panel-default">
                        <div class="panel-heading panel-b0">
                            <h4>#9</h4>
                        </div>
                        <div class="panel-body panelimg">
                            <div class="inner">
                                 <img src="img/2.jpg" class="img-responsive" alt="responsive image">
                            </div>
                             <p>
                                 2 MP camera<br>
                                 Rs.2000
                             </p>
                             <button class="btn btn-success btn-block">ADD TO CART</button>
                        </div>
                          
                    </div>
                </div>
                <div class="col-xs-2">
                    <div class="panel panel-default">
                        <div class="panel-heading panel-b0">
                            <h4>#10</h4>
                        </div>
                        <div class="panel-body panelimg">
                            <div class="inner">
                                 <img src="img/1.jpg" class="img-responsive" alt="responsive image">
                            </div>
                             <p>
                                 2 MP camera<br>
                                 Rs.2000
                             </p>
                             <button class="btn btn-success btn-block">ADD TO CART</button>
                        </div>
                          
                    </div>
                </div>
                
            </div>
        </div>
    </body>
</html>
