<?php
session_start();
if(!isset($_SESSION['name'])){
   
   header('Location:index.php');
    exit();
}

?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>My Cart</title>
         <?php
          include ("includes/links.php");
         ?>
    </head>
    <body>
        <?php
        include ("includes/homeheader.php");
        ?>
    </body>
</html>
