<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>ABOUT US</title>
         <?php
          include ("includes/links.php");
         ?>
    </head>
    <body>
        <?php
            include ("includes/header.php");
        ?>
        <div class="container margin margin-btm">
            <div class="row">
                <div class="col-xs-10">
                    <h2>
                        Live Support
                    </h2>
                    <h5>
                        24 Hours | 7 Days a week | 365 days a year Live Technical Support
                    </h5>
                    <p>
                       It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.
                       The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. 
                       Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy.
                       Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).

 
                    </p>
                </div>
                <div class="col-xs-2">
                    <img src="img/customer.jpg" class="img-responsive img-rounded" alt="customer">
                </div>
            </div>
             <div class="row">
                <div class="col-xs-8">
                    <h2>
                        Contact Us
                    </h2>
                     <form>
                                <div class="form-group">
                                    <label for="name">Name:</label>
                                    <input type="text" class="form-control" name="name" >
                                </div>
                                <div class="form-group">
                                    <label for="email">Email:</label>
                                    <input type="text" class="form-control" name="email">
                                </div>
                                <div class="form-group">
                                    <label for="message">Message:</label>
                                   <textarea class="form-control" id="message" rows="3"></textarea>
                                </div>
                                 <div class="form-group">
                                    <button class="btn btn-primary">Submit</button>
                                </div>   
                                    
                            </form>
                    
                </div>
                 <div class="col-xs-4">
                    <h2>
                        Company Information
                    </h2>
                     <p>
                         No.44 & 97/A, E-Commerce Avenue, Hosur Road, Electronic City, Bangalore - 560100<br> Next to SBI Bank
                         <br> India<br><br>
                         Phone :(11) 222 666 444<br>
                         Fax :(333) 111 444 00 6<br>
                         E-mail : info@ecommerce.com<br>
                         Follow on : Facebook and Twitter
                     </p>
                </div>
            </div>
        </div>
        <?php
            include ("includes/footer.php");
        ?>
         <?php
            include ("includes/login-modal.php");
        ?>
    </body>
</html>
