<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php
        // put your code here
 ?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>About us</title>
         <?php
          include ("includes/links.php");
         ?>
    </head>
    <body>
        <?php 
         include ("includes/header.php");
        ?>
        <div class="container-fluid margin">
            <div class="row">           
                <div class="col-xs-4">
                    <div class="panel panel-default margin-btm panel-b0">
                        <div class="panel-heading panel-b0">
                            <h5>WHO WE ARE</h5>
                        </div>
                        <div class="panel-body">
                             <img src="img/teams.jpg" class="img-responsive" alt="team">
                             <p>
                                E-Commerce is an Indian e-commerce company based in Bangalore, Karnataka, India. It was founded by Sumit Kumar Mishra in 2020. The company initially focused 
                                on book sales, before expanding into other product categories such as consumer electronics, fashion, home essentials & groceries, and lifestyle products.
                             </p>
                             <p>
                                 The service competes primarily with Amazon's Indian subsidiary, and the domestic rival Snapdeal.As of March 2017,E-Commerce held a 39.5% market share of India's e-commerce industry.
                                 E-Commerce is significantly dominant in the sale of apparel (a position that was bolstered by its acquisition of Myntra), and was described as being "neck and neck" with Amazon in the sale of electronics and mobile phones.
                                 E-Commerse also owns PhonePe, a mobile payments service based on the Unified Payments Interface (UPI).
                             </p>
                             
                        </div>
                          
                    </div>
                </div>
                <div class="col-xs-4">
                    <div class="panel panel-default panel-b0">
                        <div class="panel-heading panel-b0">
                            <h5>OUR HISTORY</h5>
                        </div>
                        <div class="panel-body">
                            <b style="color:blue;">1994–1998</b>
                             <p>
                                Amazon starts off as an online bookstore selling books, primarily competing with local booksellers and Barnes & Noble. It IPOs in 1997.
                             </p>
                             <b style="color:blue;">1998-2004</b>
                             <p>
                                 Amazon starts to expand its services beyond books. It also starts offering convenience services, such as Free Super Savers Shipping.
                             </p>
                             <b style="color:blue;">2005–2011</b>
                             <p>
                                 Amazon moves into the cloud computing area with Amazon AWS, as well as the crowdsourcing area with Amazon Mechanical Turk. 
                                 By being an early player, it eventually dominates the cloud computing scene, allowing it to control much of the physical infrastructure of the Internet.
                                 Amazon also offers the Amazon Kindle for people to purchase their books as eBooks, and by 2010, more people buy ebooks than physical books off of Amazon
                             </p>
                             <b style="color:blue;">2011–2015</b>
                             <p>
                                 Amazon starts offering streaming services like Amazon Music and Amazon Video. By 2015, its market capitalization surpasses that of Walmart.
                             </p>
                        </div>
                          
                    </div>
                </div>
                <div class="col-xs-4">
                    <div class="panel panel-default panel-b0">
                        <div class="panel-heading panel-b0">
                            <h5>OPPORTUNITIES</h5>
                        </div>
                        <div class="panel-body">
                            <h6><b>Available Roles</b></h6>
                             <p>
                             <ol type="1">
                                 <li>
                                     Jr/Sr Web Developer [Full Time Role + also available as a 6 Months Internships]<br>
                                 </li><br>
                                 <li>
                                     Business Apprentice [6 Months Internships]
                                 </li><br>
                                 <li>
                                    Manager at Backend Operations [Full Time Role + also available as a 6 Months Internships] 
                                 </li>
                                 
                             </ol>
                                  
                             </p>
                             
                        </div>
                          
                    </div>
                </div>
            </div>
            
        </div>
         <?php 
         include ("includes/footer.php");
        ?>
        <?php 
         include ("includes/login-modal.php");
        ?>
        
    </body>
</html>
