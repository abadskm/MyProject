<?php
session_start();
?>
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>sign up</title>
         <?php
          include ("includes/links.php");
         ?>
        
       
    </head>
    <body>
        <?php
            include ("includes/header.php");
        ?>
         <?php
            include ("includes/dbcon.php");
           if(isset($_POST['submit']))
           {
               $name= mysqli_real_escape_string($con,$_POST['name']);
               $email=mysqli_real_escape_string($con,$_POST['email']);
               $password=mysqli_real_escape_string($con,$_POST['pswd']);
               $cpassword=mysqli_real_escape_string($con,$_POST['cnfpswd']);
               $contact=mysqli_real_escape_string($con,$_POST['contact']);
               $address=mysqli_real_escape_string($con,$_POST['address']);
               
               $pass= password_hash($password,PASSWORD_BCRYPT);
               $cpass= password_hash($cpassword,PASSWORD_BCRYPT);
               
               $emailquery="select * from signup where email='$email'";
               $query= mysqli_query($con, $emailquery);
               $emailcount= mysqli_num_rows($query);
               if($emailcount>0)
               {
                ?> 
                   <script>
                   alert("E-mail already exists...Try with another E-mail Id");
                 </script>
                <?php 
               }
               else
               {
                   if($password===$cpassword)
                   {
                        $insertquery="INSERT INTO signup(name, email, password, cpassword, contact, address) VALUES ('$name','$email','$pass','$cpass','$contact','$address')";
                         $iquery= mysqli_query($con, $insertquery);
                         
                         if($iquery){
                            
                                        ?> 
                                             <script>
                                                alert("Signed Up Successfully");
                                             </script>
                                        <?php
                                          $_SESSION['name']=$name;
                                          $_SESSION['email']=$email;
                                         header('Location:home.php');
                                         
                                     }
                         else{
                                ?> 
                                   <script>
                                        alert("Can't Be Signed Up");
                                    </script>
                                <?php
                                header('Location:index.php');
                              
                             }
                        
                             
                   }
                   else
                   {
                       ?> 
                        <script>
                        alert("passwords do not match..try again!!");
                      </script>
                     <?php 
                   }
                       
               }
           }
        ?>
        <div class="container margin margin-btm" style="font-size:12px;">
            <div class="row">
                <div class="col-xs-8">
                    
                        <div id="slider">
                           
                            <figure>
                                    <img src="img/shopping.jpg" class="img-responsive ">
                                
                                    <img src="img/shopping1.jpg" class="img-responsive ">
                               
                                    <img src="img/shopping2.jpg" class="img-responsive">
                                
                                    <img src="img/shopping3.jpg" class="img-responsive">
                                
                                    <img src="img/shopping4.jpg" class="img-responsive">
                            </figure>   
                           
                        </div>   
                    
                       
                </div>
                <div class="col-xs-4" style="background-color:#E7EAE8">
                    <center><h2>Create Account</h2></center><br>
                    <form action="<?php echo htmlentities($_SERVER['PHP_SELF']);  ?>" method="post">
                                <div class="form-group">
                                    <label for="name">Name:</label>
                                    <input type="text" class="form-control" name="name" required >
                                </div>
                                <div class="form-group">
                                    <label for="email">Email:</label>
                                    <input type="text" class="form-control" name="email" required>
                                </div>
                                <div class="form-group">
                                    <label for="pswd">Password:</label>
                                    <input type="password" class="form-control" name="pswd" placeholder="At least 6 characters" required>
                                </div>
                                <div class="form-group">
                                    <label for="cnfpswd">Confirm Password:</label>
                                    <input type="password" class="form-control" name="cnfpswd" required >
                                </div>
                                <div class="form-group">
                                    <label for="contact">Contact:</label>
                                    <input type="number" class="form-control" name="contact" placeholder="Mobile number" required>
                                </div>
                        
                                
                                <div class="form-group">
                                    <label for="address">Address:</label>
                                   <textarea class="form-control" name="address" rows="2" required ></textarea>
                                </div>
                                
                                 <div class="form-group">
                                     <button type="submit" name="submit" class="btn btn-success btn-block">Sign Up</button>
                                </div>   
                                    
                            </form>
                    <h5>Have an account?<a href="#" data-toggle="modal" data-target="#mymodal">Login</a></h5>
                </div>
            </div>
        </div>
        
         <?php
            include ("includes/footer.php");
        ?>
        
        <?php
            include ("includes/login-modal.php");
        ?>
    </body>
</html>
