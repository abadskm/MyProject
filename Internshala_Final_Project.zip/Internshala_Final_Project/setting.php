<?php
session_start();
if(!isset($_SESSION['name'])){
   
   header('Location:index.php');
    exit();
}
?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>settings</title>
         <?php
          include ("includes/links.php");
         ?>
    </head>
    <body>
        <?php
        include ("includes/homeheader.php");
        ?>
        <?php
            include ("includes/dbcon.php");
       if(isset($_POST['submit']))
       {   
            $oldpswd=$_POST['oldpswd'];
            $newpswd=$_POST['newpswd'];
            $repswd=$_POST['cnfpswd'];
            $sess_email=$_SESSION['email'];
            $email_search="select * from signup where email='$sess_email'";
            $query= mysqli_query($con, $email_search);
            
           
                $email_pass= mysqli_fetch_assoc($query);
                $db_pass=$email_pass['password'];
               
                $pass_decode= password_verify($oldpswd, $db_pass);
                if($pass_decode){
                    if($newpswd===$repswd)
                   {
                        $pass= password_hash($newpswd,PASSWORD_BCRYPT);
                        $updatequery="update signup set password='$pass' where signup.email='$sess_email'";
                         $iquery= mysqli_query($con, $updatequery);
                         
                         if($iquery){
                            
                                        ?> 
                                             <script>
                                                alert("Password Changed Successfully");
                                             </script>
                                        <?php
                                     }
                                          
                         else{
                                ?> 
                                   <script>
                                        alert("cant change password");
                                    </script>
                                <?php
                               
                              
                             }
                        
                             
                   }
                   else
                   {
                       ?> 
                        <script>
                        alert("passwords do not match..try again!!");
                      </script>
                     <?php 
                   }
                    
                }
                else{
                    ?>
                    <script>
                        alert("old password incorrect");
                    </script>
                    <?php
                  
                }
            
            
       }
        ?>
        
        
        <div class="container">
            <div class="row">
                <div class="col-xs-4"></div>
                <div class="col-xs-4">
             <h3>Change Password</h3>
        
            <form action="<?php echo htmlentities($_SERVER['PHP_SELF']);  ?>" method="post">
                <div class="form-group">
                  <input type="password" class="form-control" name="oldpswd" placeholder="Old Password">
                </div>
                <div class="form-group">
                  <input type="password" class="form-control" name="newpswd" placeholder="New Password">
                </div>
                <div class="form-group">
                  <input type="password" class="form-control" name="cnfpswd" placeholder="Retype Password">
                </div>
                <div class="form-group">
                  <button type="submit" name="submit" class="btn btn-success btn-block">Change</button>
                </div>  
            </form>
             <div class="col-xs-4">
            </div>
        </div>
    </body>
</html>
