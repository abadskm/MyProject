
<!DOCTYPE html>
 
<html>
    <head>
        
        <title>index</title>
        <?php
          include ("includes/links.php");
         ?>
    </head>
    <body>
        <?php
          include ("includes/header.php");
         ?>  
        <div class="container-fluid">
            <div class="row">
                <div class="col-xs-3 margin">
                    <div class="panel panel-default">
                        <div class="panel-heading panel-b0">
                            <h4>Item 1</h4>
                        </div>
                        <div class="panel-body panelimg">
                            <div class="inner">
                                <img src="img/1.jpg" class="img-responsive" alt="responsive image">
                            </div>
                             <p>
                                 Buy At<br>
                                 Rs.2000
                             </p>
                             <button class="btn btn-success btn-block">Order Now</button>
                        </div>
                          
                    </div>
                </div>
                <div class="col-xs-3 margin">
                    <div class="panel panel-default">
                        <div class="panel-heading panel-b0">
                           <h4>Item 2</h4>
                        </div>
                        <div class="panel-body panelimg">
                            <div class="inner">
                                <img src="img/2.jpg" class="img-responsive" alt="responsive image">
                            </div>
                             <p>
                                 Buy At<br>
                                 Rs.2000
                             </p>
                             <button class="btn btn-success btn-block">Order Now</button>
                        </div>
                          
                    </div>
                </div>
                <div class="col-xs-3 margin">
                    <div class="panel panel-default">
                        <div class="panel-heading panel-b0">
                            <h4>Item 3</h4>
                        </div>
                        <div class="panel-body panelimg">
                            <div class="inner">
                                 <img src="img/3.jpg" class="img-responsive" alt="responsive image">
                            </div>
                             <p>
                                 Buy At<br>
                                 Rs.2000
                             </p>
                             <button class="btn btn-success btn-block">Order Now</button>
                        </div>
                          
                    </div>
                </div>
           
             <div class="col-xs-3 margin">
                    <div class="panel panel-default">
                        <div class="panel-heading panel-b0">
                           <h4>Item 4</h4>
                        </div>
                        <div class="panel-body panelimg">
                            <div class="inner">
                                <img src="img/4.jpg" class="img-responsive" alt="responsive image">
                            </div>
                             <p>
                                 Buy At<br>
                                 Rs.2000
                             </p>
                             <button class="btn btn-success btn-block">Order Now</button>
                        </div>
                          
                    </div>
                </div>
             </div>    
            <div class="row margin-btm">
                <div class="col-xs-2">
                    <div class="panel panel-default">
                        <div class="panel-heading panel-b0">
                            <h4>Item 5</h4>
                        </div>
                        <div class="panel-body panelimg">
                            <div class="inner">
                                 <img src="img/5.jpg" class="img-responsive" alt="responsive image">
                            </div>
                             <p>
                                 Buy At<br>
                                 Rs.2000
                             </p>
                             <button class="btn btn-success btn-block">Order Now</button>
                        </div>
                          
                    </div>
                </div>
                <div class="col-xs-2">
                    <div class="panel panel-default">
                        <div class="panel-heading panel-b0">
                            <h4>Item 6</h4>
                        </div>
                        <div class="panel-body panelimg">
                            <div class="inner">
                                 <img src="img/6.jpg" class="img-responsive" alt="responsive image">
                            </div>
                             <p>
                                 Buy At<br>
                                 Rs.2000
                             </p>
                             <button class="btn btn-success btn-block">Order Now</button>
                        </div>
                          
                    </div>
                </div>
                <div class="col-xs-2">
                    <div class="panel panel-default">
                        <div class="panel-heading panel-b0">
                            <h4>Item 7</h4>
                        </div>
                        <div class="panel-body panelimg">
                            <div class="inner">
                                <img src="img/7.jpg" class="img-responsive" alt="responsive image">
                            </div>
                             <p>
                                 Buy At<br>
                                 Rs.2000
                             </p>
                             <button class="btn btn-success btn-block">Order Now</button>
                        </div>
                          
                    </div>
                </div>
                 <div class="col-xs-2">
                    <div class="panel panel-default">
                        <div class="panel-heading panel-b0">
                            <h4>Item 8</h4>
                        </div>
                        <div class="panel-body panelimg">
                            <div class="inner">
                                 <img src="img/8.jpg" class="img-responsive" alt="responsive image">
                            </div>
                             <p>
                                 Buy At<br>
                                 Rs.2000
                             </p>
                             <button class="btn btn-success btn-block">Order Now</button>
                        </div>
                          
                    </div>
                </div>
                <div class="col-xs-2">
                    <div class="panel panel-default">
                        <div class="panel-heading panel-b0">
                            <h4>Item 9</h4>
                        </div>
                        <div class="panel-body panelimg">
                            <div class="inner">
                                 <img src="img/9.jpg" class="img-responsive" alt="responsive image">
                            </div>
                             <p>
                                 Buy At<br>
                                 Rs.2000
                             </p>
                             <button class="btn btn-success btn-block">Order Now</button>
                        </div>
                          
                    </div>
                </div>
                <div class="col-xs-2">
                    <div class="panel panel-default">
                        <div class="panel-heading panel-b0">
                            <h4>Item 10</h4>
                        </div>
                        <div class="panel-body panelimg">
                            <div class="inner">
                                 <img src="img/10.jpg" class="img-responsive" alt="responsive image">
                            </div>
                             <p>
                                 Buy At<br>
                                 Rs.2000
                             </p>
                             <button class="btn btn-success btn-block">Order Now</button>
                        </div>
                          
                    </div>
                </div>
                
            </div>
        </div>
        
        <?php
          include ("includes/footer.php");
         ?>
        <?php
          include ("includes/login-modal.php");
         ?>
        
    </body>
</html>
