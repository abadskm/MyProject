<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <script type="text/javascript" src="bootstrap/js/jquery-3.5.1.min.js"></script>
          <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script> 
          <link rel="stylesheet" href="mycss/styles.css" type="text/css">