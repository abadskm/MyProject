<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->

 <div class="container footer">
            <div class="row">
                <div class="col-xs-4">
                    <h4>Information</h4>
                    <br>
                    <a href="about.php" class="none"> About us</a><br>
                    <a href="contact.php" class="none">Contact us</a>                    
                </div>
                <div class="col-xs-4">
                    <h4>My Account</h4>
                    <br>
                    <a href="#" data-toggle="modal" data-target="#mymodal" class="none">Login</a><br>
                    <a href="signup.php" class="none">Sign up</a>                    
                </div>
                <div class="col-xs-4">
                    <h4>Contact us</h4>
                    <br>
                    Contact: +917488170456
                                        
                </div>
            </div>
                                           
        </div>