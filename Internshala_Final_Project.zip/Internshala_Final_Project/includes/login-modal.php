
<div class="modal fade" id="mymodal">
            <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4>Login</h4>
                        </div>
                        <div class="modal-body">
                            Don't have an account? <a href="signup.php">Register</a><br>
                            <form action="validation.php" method="post">
                                <div class="form-group">
                                    <input type="text" class="form-control" name="email" placeholder="E-mail">
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control" name="password" placeholder="Password">
                                </div>
                                 <div class="form-group">
                                     <input type="submit" name="submit" value="Login" class="btn btn-success">
                                </div>   
                                    
                            </form>
                            
                            
                        </div>
                        <div class="modal-footer" style="text-align: left">
                            <a href="#"> Forgot Password?</a>
                        </div>
                        
                    </div>
                    
                </div>
                
            </div>