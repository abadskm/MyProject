<?php 
session_start();

?>
<!DOCTYPE html>


       
        <div class="container">
        <nav class=" navbar navbar-default navbar-fixed-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a href="index.php" class="navbar-brand"><img src="img/logo.png" alt="E-Store" class="img-responsive logo"></a>    
                </div>
                <div class="collapse navbar-collapse" id="myNavbar">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="index.php"><span class="glyphicon glyphicon-fire"><b>
                            <?php
                            if(isset($_SESSION['id'])){
                                echo $_SESSION['email'];
                            }
                            else {
                                echo "Hi,Guest";
                                }
                            ?>
                             </b></span></a>
                        </li>          
                        <li><a href="#" data-toggle="modal" data-target="#mymodal"><span class="glyphicon glyphicon-log-in"><b>Login</b></span></a></li>
                        <li><a href="signup.php"><span class="glyphicon glyphicon-user"><b>Sign Up</b></span></a></li>
                        <li><a href="about.php"><span class="glyphicon glyphicon-tasks"><b>About Us</b></span></a></li>
                        <li><a href="contact.php"><span class="glyphicon glyphicon-phone"><b>Contact Us</b></span></a></li>&nbsp;&nbsp;
                        
                    </ul>
                </div>
                
            </div>
        </nav>
        </div>  
   
