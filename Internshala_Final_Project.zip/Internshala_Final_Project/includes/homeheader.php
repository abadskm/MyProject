<?php
session_start();
?>
<!DOCTYPE html>


       
        <div class="container">
        <nav class=" navbar navbar-default navbar-fixed-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a href="home.php" class="navbar-brand"><img src="img/logo.png" alt="E-Store" class="img-responsive logo"></a>    
                </div>
                <div class="collapse navbar-collapse" id="myNavbar">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="home.php"><span class="glyphicon glyphicon-fire"><b>
                            <?php
                            
                                echo "Hi,".$_SESSION['name'];
                            
                            
                            ?>
                             </b></span></a>
                        </li>
                        <li><a href="cart.php"><span class="glyphicon glyphicon-shopping-cart"><b>Cart</b></span></a></li>
                       <li><a href="setting.php"><span class="glyphicon glyphicon-cog"><b>Settings</b></span></a></li>
                        <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"><b>Logout</b></span></a></li>
                        
                        
                    </ul>
                </div>
                
            </div>
        </nav>
        </div>  
   
