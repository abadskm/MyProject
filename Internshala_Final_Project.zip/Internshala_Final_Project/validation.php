
        <?php
       session_start();
       ?>
      <?php
       include ("includes/dbcon.php");
       if(isset($_POST['submit']))
       {   
            $email=$_POST['email'];
            $password=$_POST['password'];
            
            $email_search="select * from signup where email='$email'";
            $query= mysqli_query($con, $email_search);
            
            $email_count= mysqli_num_rows($query);
            if($email_count){
                $email_pass= mysqli_fetch_assoc($query);
                $db_pass=$email_pass['password'];
                $_SESSION['name']=$email_pass['name'];
                $_SESSION['email']=$email_pass['email'];
                $pass_decode= password_verify($password, $db_pass);
                if($pass_decode){
                    ?>
                    <script>
                        alert("login successful");
                        
                    </script>
                    <?php
                     header('location:home.php');
                }
                else{
                    ?>
                    <script>
                        alert("password incorrect");
                    </script>
                    <?php
                    header('location:index.php');
                }
            }else{
                ?>
                    <script>
                        alert("invalid email");
                    </script>
                    <?php
                    header('location:index.php');
            }
       }
        ?>
    